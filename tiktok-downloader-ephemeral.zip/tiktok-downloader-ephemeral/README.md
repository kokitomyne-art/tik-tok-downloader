# TikTok Downloader (descargar y borrar)

- Backend: Flask + yt-dlp
- Descarga el vídeo y lo borra inmediatamente después de enviarlo al cliente (no hay almacenamiento permanente).
- Frontend: `static/index.html` (envía la URL y recibe el archivo directamente).

## Requisitos (local)
- Python 3.11+
- `pip install -r requirements.txt`
- **FFmpeg** instalado en el sistema (Windows: winget/choco; macOS: brew; Linux: apt).

## Ejecutar en local
```bash
python app.py
# Abre http://127.0.0.1:5000
```

## Despliegue en Render (Docker)
- Subir repo a GitHub con estos archivos (incluye Dockerfile).
- Crear Web Service en Render eligiendo "Docker" como Runtime.
- No hace falta disco persistente ya que no guardamos archivos.
