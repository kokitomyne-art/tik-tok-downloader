from flask import Flask, request, jsonify, send_file, send_from_directory, after_this_request
import yt_dlp
import tempfile
import uuid
import os

app = Flask(__name__, static_folder="static", static_url_path="")

@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")

@app.route("/api/download-tiktok", methods=["POST"])
def download_tiktok():
    data = request.get_json(silent=True) or {}
    url = (data.get("url") or "").strip()
    if not url:
        return jsonify({"success": False, "error": "No se recibió ninguna URL."}), 400

    # Crear ruta de archivo temporal
    tmp_dir = tempfile.gettempdir()
    tmp_filename = f"tiktok_{uuid.uuid4()}.mp4"
    tmp_path = os.path.join(tmp_dir, tmp_filename)

    ydl_opts = {
        "outtmpl": tmp_path,
        "format": "bestvideo+bestaudio/best",
        "merge_output_format": "mp4",
        "noprogress": True,
        "quiet": True,
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

    # Programar borrado del archivo una vez enviado
    @after_this_request
    def cleanup(response):
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
        return response

    # Enviar el archivo directamente como descarga
    return send_file(tmp_path, as_attachment=True, download_name="tiktok.mp4")

if __name__ == "__main__":
    import os
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
